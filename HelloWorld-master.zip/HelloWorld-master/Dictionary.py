

Dict= {};
for i in range (0,31):

    Dict=i*i
    print(Dict)


dictionary1 = {'Tony': 41, 'Steve': 39, 'Nat': 35}
dictionary2 = {'Bruce': 41, 'Clint': 35, 'Thor': 38}
merged_dictionary=dict()
merged_dictionary.update(dictionary1)
merged_dictionary.update(dictionary2)
print(merged_dictionary)

